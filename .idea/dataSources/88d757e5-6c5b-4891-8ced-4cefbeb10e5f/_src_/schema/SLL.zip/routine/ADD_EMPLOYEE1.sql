create procedure ADD_EMPLOYEE1(
eno employee.empno%type,
name employee.ename%type,
salary employee.sal%type,
job employee.job%type default 'clerk',
dno employee.deptno%type,
on_Flag out number,
os_Msg out varchar2
)
is
e_eno exception;
begin
  if length(eno)<4 then
    raise e_eno;
 end if;
 insert into employee
 (empno,ename,sal,job,deptno) values(eno,name,salary,job,dno);
 on_Flag:=1;
 os_Msg:='添加成功';
exception
    when e_eno then
       on_Flag:=-1;
       os_Msg:='员工编号不能小于4位';
    when DUP_VAL_ON_INDEX then
       on_Flag:=-2;
       os_Msg:='员工已经存在';
    when others then
       on_Flag:=-3;
       os_Msg:='其他错误，与管理员联系';
 end;
