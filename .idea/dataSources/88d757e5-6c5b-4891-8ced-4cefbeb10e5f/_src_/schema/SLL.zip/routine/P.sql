create procedure P(
A PLS_INTEGER,
B IN PLS_INTEGER,
C OUT PLS_INTEGER,
D IN OUT NUMBER
)IS
BEGIN
  IF c IS NULL THEN
        dbms_output.put_line('NULL');
   ELSE
       dbms_output.put_line(C);
   END IF;
       dbms_output.put_line(D);
       C:=A+10;
       D:=10/B;
END;
