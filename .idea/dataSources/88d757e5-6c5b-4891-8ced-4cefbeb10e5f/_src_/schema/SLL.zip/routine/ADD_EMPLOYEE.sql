create procedure ADD_EMPLOYEE(
eno number,
name varchar2,
salary number,
job varchar2 default 'clerk',
dno number
)
is
begin
  if length(eno)<4 then
    raise_application_error(-20000,'员工编号不能小于4位');
 end if;
 insert into employee
 (empno,ename,sal,job,deptno) values(eno,name,salary,job,dno);
exception
  when others then
    --dbms_output.put_line(SQLERRM);
    RAISE;
 end;
