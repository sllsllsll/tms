create procedure account_status(
due_date date,
today date
)
is
past_due exception;
begin
  if due_date<today then
    raise past_due;
  end if;
exception
  when past_due then
    dbms_output.put_line('Account past due.');
end;
